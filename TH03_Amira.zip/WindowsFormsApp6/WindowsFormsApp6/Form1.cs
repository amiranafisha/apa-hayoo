﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp6
{
    public partial class Form1 : Form
    {
        DataTable dtBank = new DataTable();
        private decimal saldo = 0;
        private List<string> InputUsername = new List<string>();
        private List<string> InputPassword = new List<string>();
        private List<int> Balance = new List<int>();
        int indexAkun;
        string Rupiah;

        public Form1()
        {
            InitializeComponent();
            InisialisasiDataTable();

            panel_TampilanRegister.Visible = false;
            panel_DepositView.Visible = false;
            panel_WithdrawView.Visible = false;
        }

        private void InisialisasiDataTable()
        {
            dtBank.Columns.Add("Username");
            dtBank.Columns.Add("Password");
        }

        private void btn_Login_TampilanLogin_Click(object sender, EventArgs e)
        {
            string username = textBox_Username_TampilanLogin.Text;
            string password = textBox_Password_TampilanLogin.Text;

            DataRow[] foundRows = dtBank.Select($"Username = '{username}' AND Password = '{password}'");

            if (foundRows.Length == 0)
            {
                MessageBox.Show("Username and Password not found!");
            }
            else
            {
                MessageBox.Show("Login Successful");
                panel_TampilanDeposit.Visible = true;
                panel_TampilanLogin.Visible = false;
                panel_TampilanRegister.Visible = false;
            }
        }

        private void textBox_Username_TampilanRegister_TextChanged(object sender, EventArgs e)
        {
            string username = textBox_Username_TampilanRegister.Text;

            DataRow[] foundRows = dtBank.Select($"Username = '{username}'");
            if (foundRows.Length > 0)
            {
                MessageBox.Show("Username has been used");
                btn_Register.Enabled = false;
            }
            else
            {
                btn_Register.Enabled = true;
            }
        }

        private void btn_Register_Click(object sender, EventArgs e)
        {
            string username = textBox_Username_TampilanRegister.Text;
            string password = textBox_Password_TampilanRegister.Text;

            DataRow[] foundRows = dtBank.Select($"Username = '{username}'");
            if (foundRows.Length > 0)
            {
                MessageBox.Show("Username has been used");
            }
            else
            {
                dtBank.Rows.Add(username, password);
                MessageBox.Show("Register Successful");

                indexAkun = dtBank.Rows.Count - 1;
                Balance.Add(0);

                panel_TampilanRegister.Visible = false;
                panel_TampilanLogin.Visible = true;
            }
            textBox_Username_TampilanRegister.Clear();
            textBox_Password_TampilanRegister.Clear();
        }

        private void btn_Register_TampilanLogin_Click(object sender, EventArgs e)
        {
            panel_TampilanRegister.Visible = true;
            panel_TampilanLogin.Visible = false;
        }

        private void btn_Deposit_Click(object sender, EventArgs e)
        {
            panel_DepositView.Visible = true;
            panel_TampilanDeposit.Visible = false;
        }

        private void btn_DepositView_Click(object sender, EventArgs e)
        {

            if (Convert.ToInt32(textBox_JumlahDeposit.Text) <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            else
            {
                int depositAmount = Convert.ToInt32(textBox_JumlahDeposit.Text);
                Balance[indexAkun] = Balance[indexAkun] + depositAmount;
                MessageBox.Show("Successfully Add Deposit");

                lb_0_TampilanDeposit.Text = UbahRupiah(Balance[indexAkun]);
                lb_0_TampilanWithdrawView.Text = UbahRupiah(Balance[indexAkun]);
            }

            textBox_JumlahDeposit.Clear();
            panel_DepositView.Visible = false;
            panel_WithdrawView.Visible = true;
        }
        private void panel_TampilanDeposit_VisibleChanged(object sender, EventArgs e)
        {
            lb_0_DepositView.Text = UbahRupiah(Balance[indexAkun]);
            lb_0_TampilanWithdrawView.Text = UbahRupiah(Balance[indexAkun]);
        }

        public string UbahRupiah(decimal saldo)
        {
            return string.Format(CultureInfo.CreateSpecificCulture("id-ID"), "{0:C2}", saldo);
        }
        private void btn_Withdraw_TampilanDeposit_Click(object sender, EventArgs e)
        {
            panel_WithdrawView.Visible = true;
        }

        private void btn_LogOut_DepositView_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panel_TampilanDeposit.Visible = false;
            panel_TampilanLogin.Visible = true;
        }

        private void btn_Withdraw_WithdrawView_Click(object sender, EventArgs e)
        {
            int withdrawalAmount = Convert.ToInt32(textBox_JumlahWithdrawal.Text);

            if (withdrawalAmount > Balance[indexAkun])
            {
                MessageBox.Show("Withdrawal Failed. Not Enough Balance.");
            }
            else if (withdrawalAmount <= 0)
            {
                MessageBox.Show("Withdrawal Amount Can't be less than 1");
            }
            else
            {
                Balance[indexAkun] -= withdrawalAmount;
                lb_0_TampilanDeposit.Text = UbahRupiah(Balance[indexAkun]);
                lb_0_TampilanWithdrawView.Text = UbahRupiah(Balance[indexAkun]);
            }

            textBox_JumlahWithdrawal.Clear();
            panel_WithdrawView.Visible = false;
            panel_TampilanDeposit.Visible = true;
        }

        private void btn_LogOut_Depsoit_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panel_TampilanDeposit.Visible = false;
            panel_TampilanLogin.Visible = true;
        }

        private void btn_LogOut_WithdrawView_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Log Out Berhasil");
            panel_TampilanDeposit.Visible = false;
            panel_TampilanLogin.Visible = true;
        }
    }
}
