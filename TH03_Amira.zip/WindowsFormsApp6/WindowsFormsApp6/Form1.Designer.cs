﻿namespace WindowsFormsApp6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_UC_Bank = new System.Windows.Forms.Label();
            this.lb_Username_TampilanLogin = new System.Windows.Forms.Label();
            this.lb_Password_TampilanLogin = new System.Windows.Forms.Label();
            this.textBox_Username_TampilanLogin = new System.Windows.Forms.TextBox();
            this.textBox_Password_TampilanLogin = new System.Windows.Forms.TextBox();
            this.btn_Register_TampilanLogin = new System.Windows.Forms.Button();
            this.btn_Login_TampilanLogin = new System.Windows.Forms.Button();
            this.panel_TampilanLogin = new System.Windows.Forms.Panel();
            this.panel_TampilanRegister = new System.Windows.Forms.Panel();
            this.textBox_Password_TampilanRegister = new System.Windows.Forms.TextBox();
            this.lb_UCBank_TampilanRegister = new System.Windows.Forms.Label();
            this.textBox_Username_TampilanRegister = new System.Windows.Forms.TextBox();
            this.lb_Password_TampilanRegister = new System.Windows.Forms.Label();
            this.btn_Register = new System.Windows.Forms.Button();
            this.lb_Username_TampilanRegister = new System.Windows.Forms.Label();
            this.panel_TampilanDeposit = new System.Windows.Forms.Panel();
            this.btn_Withdraw_TampilanDeposit = new System.Windows.Forms.Button();
            this.btn_Deposit = new System.Windows.Forms.Button();
            this.lb_0_TampilanDeposit = new System.Windows.Forms.Label();
            this.b_Balance_TampilanDeposit = new System.Windows.Forms.Label();
            this.btn_LogOut_Depsoit = new System.Windows.Forms.Button();
            this.lb_UCBank_Deposit = new System.Windows.Forms.Label();
            this.panel_WithdrawView = new System.Windows.Forms.Panel();
            this.btn_LogOut_WithdrawView = new System.Windows.Forms.Button();
            this.lb_0_TampilanWithdrawView = new System.Windows.Forms.Label();
            this.lb_InputWithdrawalAmount = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Withdraw_WithdrawView = new System.Windows.Forms.Button();
            this.textBox_JumlahWithdrawal = new System.Windows.Forms.TextBox();
            this.lb_UCBank_WithdrawView = new System.Windows.Forms.Label();
            this.panel_DepositView = new System.Windows.Forms.Panel();
            this.lb_DepositView = new System.Windows.Forms.Label();
            this.textBox_JumlahDeposit = new System.Windows.Forms.TextBox();
            this.btn_Deposit_DepositView = new System.Windows.Forms.Button();
            this.lb_0_DepositView = new System.Windows.Forms.Label();
            this.lb_Balance_DepositView = new System.Windows.Forms.Label();
            this.btn_LogOut_DepositView = new System.Windows.Forms.Button();
            this.lb_UCBank_DepositView = new System.Windows.Forms.Label();
            this.panel_TampilanLogin.SuspendLayout();
            this.panel_TampilanRegister.SuspendLayout();
            this.panel_TampilanDeposit.SuspendLayout();
            this.panel_WithdrawView.SuspendLayout();
            this.panel_DepositView.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_UC_Bank
            // 
            this.lb_UC_Bank.AutoSize = true;
            this.lb_UC_Bank.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UC_Bank.Location = new System.Drawing.Point(54, 6);
            this.lb_UC_Bank.Name = "lb_UC_Bank";
            this.lb_UC_Bank.Size = new System.Drawing.Size(168, 40);
            this.lb_UC_Bank.TabIndex = 0;
            this.lb_UC_Bank.Text = "UC Bank";
            // 
            // lb_Username_TampilanLogin
            // 
            this.lb_Username_TampilanLogin.AutoSize = true;
            this.lb_Username_TampilanLogin.Location = new System.Drawing.Point(64, 61);
            this.lb_Username_TampilanLogin.Name = "lb_Username_TampilanLogin";
            this.lb_Username_TampilanLogin.Size = new System.Drawing.Size(87, 20);
            this.lb_Username_TampilanLogin.TabIndex = 5;
            this.lb_Username_TampilanLogin.Text = "Username:";
            // 
            // lb_Password_TampilanLogin
            // 
            this.lb_Password_TampilanLogin.AutoSize = true;
            this.lb_Password_TampilanLogin.Location = new System.Drawing.Point(64, 113);
            this.lb_Password_TampilanLogin.Name = "lb_Password_TampilanLogin";
            this.lb_Password_TampilanLogin.Size = new System.Drawing.Size(82, 20);
            this.lb_Password_TampilanLogin.TabIndex = 6;
            this.lb_Password_TampilanLogin.Text = "Password:";
            // 
            // textBox_Username_TampilanLogin
            // 
            this.textBox_Username_TampilanLogin.Location = new System.Drawing.Point(157, 61);
            this.textBox_Username_TampilanLogin.Name = "textBox_Username_TampilanLogin";
            this.textBox_Username_TampilanLogin.Size = new System.Drawing.Size(100, 26);
            this.textBox_Username_TampilanLogin.TabIndex = 7;
            // 
            // textBox_Password_TampilanLogin
            // 
            this.textBox_Password_TampilanLogin.Location = new System.Drawing.Point(157, 107);
            this.textBox_Password_TampilanLogin.Name = "textBox_Password_TampilanLogin";
            this.textBox_Password_TampilanLogin.Size = new System.Drawing.Size(100, 26);
            this.textBox_Password_TampilanLogin.TabIndex = 8;
            // 
            // btn_Register_TampilanLogin
            // 
            this.btn_Register_TampilanLogin.Location = new System.Drawing.Point(95, 198);
            this.btn_Register_TampilanLogin.Name = "btn_Register_TampilanLogin";
            this.btn_Register_TampilanLogin.Size = new System.Drawing.Size(108, 39);
            this.btn_Register_TampilanLogin.TabIndex = 9;
            this.btn_Register_TampilanLogin.Text = "Register";
            this.btn_Register_TampilanLogin.UseVisualStyleBackColor = true;
            this.btn_Register_TampilanLogin.Click += new System.EventHandler(this.btn_Register_TampilanLogin_Click);
            // 
            // btn_Login_TampilanLogin
            // 
            this.btn_Login_TampilanLogin.Location = new System.Drawing.Point(95, 151);
            this.btn_Login_TampilanLogin.Name = "btn_Login_TampilanLogin";
            this.btn_Login_TampilanLogin.Size = new System.Drawing.Size(108, 41);
            this.btn_Login_TampilanLogin.TabIndex = 4;
            this.btn_Login_TampilanLogin.Text = "Login";
            this.btn_Login_TampilanLogin.UseVisualStyleBackColor = true;
            this.btn_Login_TampilanLogin.Click += new System.EventHandler(this.btn_Login_TampilanLogin_Click);
            // 
            // panel_TampilanLogin
            // 
            this.panel_TampilanLogin.Controls.Add(this.textBox_Password_TampilanLogin);
            this.panel_TampilanLogin.Controls.Add(this.btn_Login_TampilanLogin);
            this.panel_TampilanLogin.Controls.Add(this.lb_UC_Bank);
            this.panel_TampilanLogin.Controls.Add(this.btn_Register_TampilanLogin);
            this.panel_TampilanLogin.Controls.Add(this.lb_Username_TampilanLogin);
            this.panel_TampilanLogin.Controls.Add(this.lb_Password_TampilanLogin);
            this.panel_TampilanLogin.Controls.Add(this.textBox_Username_TampilanLogin);
            this.panel_TampilanLogin.Location = new System.Drawing.Point(57, 12);
            this.panel_TampilanLogin.Name = "panel_TampilanLogin";
            this.panel_TampilanLogin.Size = new System.Drawing.Size(301, 248);
            this.panel_TampilanLogin.TabIndex = 10;
            // 
            // panel_TampilanRegister
            // 
            this.panel_TampilanRegister.Controls.Add(this.textBox_Password_TampilanRegister);
            this.panel_TampilanRegister.Controls.Add(this.lb_UCBank_TampilanRegister);
            this.panel_TampilanRegister.Controls.Add(this.textBox_Username_TampilanRegister);
            this.panel_TampilanRegister.Controls.Add(this.lb_Password_TampilanRegister);
            this.panel_TampilanRegister.Controls.Add(this.btn_Register);
            this.panel_TampilanRegister.Controls.Add(this.lb_Username_TampilanRegister);
            this.panel_TampilanRegister.Location = new System.Drawing.Point(12, 15);
            this.panel_TampilanRegister.Name = "panel_TampilanRegister";
            this.panel_TampilanRegister.Size = new System.Drawing.Size(381, 294);
            this.panel_TampilanRegister.TabIndex = 11;
            // 
            // textBox_Password_TampilanRegister
            // 
            this.textBox_Password_TampilanRegister.Location = new System.Drawing.Point(171, 114);
            this.textBox_Password_TampilanRegister.Name = "textBox_Password_TampilanRegister";
            this.textBox_Password_TampilanRegister.Size = new System.Drawing.Size(100, 26);
            this.textBox_Password_TampilanRegister.TabIndex = 17;
            // 
            // lb_UCBank_TampilanRegister
            // 
            this.lb_UCBank_TampilanRegister.AutoSize = true;
            this.lb_UCBank_TampilanRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank_TampilanRegister.Location = new System.Drawing.Point(68, 13);
            this.lb_UCBank_TampilanRegister.Name = "lb_UCBank_TampilanRegister";
            this.lb_UCBank_TampilanRegister.Size = new System.Drawing.Size(168, 40);
            this.lb_UCBank_TampilanRegister.TabIndex = 12;
            this.lb_UCBank_TampilanRegister.Text = "UC Bank";
            // 
            // textBox_Username_TampilanRegister
            // 
            this.textBox_Username_TampilanRegister.Location = new System.Drawing.Point(171, 68);
            this.textBox_Username_TampilanRegister.Name = "textBox_Username_TampilanRegister";
            this.textBox_Username_TampilanRegister.Size = new System.Drawing.Size(100, 26);
            this.textBox_Username_TampilanRegister.TabIndex = 16;
            this.textBox_Username_TampilanRegister.TextChanged += new System.EventHandler(this.textBox_Username_TampilanRegister_TextChanged);
            // 
            // lb_Password_TampilanRegister
            // 
            this.lb_Password_TampilanRegister.AutoSize = true;
            this.lb_Password_TampilanRegister.Location = new System.Drawing.Point(78, 120);
            this.lb_Password_TampilanRegister.Name = "lb_Password_TampilanRegister";
            this.lb_Password_TampilanRegister.Size = new System.Drawing.Size(82, 20);
            this.lb_Password_TampilanRegister.TabIndex = 15;
            this.lb_Password_TampilanRegister.Text = "Password:";
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(108, 171);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(108, 39);
            this.btn_Register.TabIndex = 18;
            this.btn_Register.Text = "Register";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // lb_Username_TampilanRegister
            // 
            this.lb_Username_TampilanRegister.AutoSize = true;
            this.lb_Username_TampilanRegister.Location = new System.Drawing.Point(78, 68);
            this.lb_Username_TampilanRegister.Name = "lb_Username_TampilanRegister";
            this.lb_Username_TampilanRegister.Size = new System.Drawing.Size(87, 20);
            this.lb_Username_TampilanRegister.TabIndex = 14;
            this.lb_Username_TampilanRegister.Text = "Username:";
            // 
            // panel_TampilanDeposit
            // 
            this.panel_TampilanDeposit.Controls.Add(this.btn_Withdraw_TampilanDeposit);
            this.panel_TampilanDeposit.Controls.Add(this.btn_Deposit);
            this.panel_TampilanDeposit.Controls.Add(this.lb_0_TampilanDeposit);
            this.panel_TampilanDeposit.Controls.Add(this.b_Balance_TampilanDeposit);
            this.panel_TampilanDeposit.Controls.Add(this.btn_LogOut_Depsoit);
            this.panel_TampilanDeposit.Controls.Add(this.lb_UCBank_Deposit);
            this.panel_TampilanDeposit.Location = new System.Drawing.Point(60, 12);
            this.panel_TampilanDeposit.Name = "panel_TampilanDeposit";
            this.panel_TampilanDeposit.Size = new System.Drawing.Size(338, 298);
            this.panel_TampilanDeposit.TabIndex = 12;
            this.panel_TampilanDeposit.Visible = false;
            this.panel_TampilanDeposit.VisibleChanged += new System.EventHandler(this.panel_TampilanDeposit_VisibleChanged);
            // 
            // btn_Withdraw_TampilanDeposit
            // 
            this.btn_Withdraw_TampilanDeposit.Location = new System.Drawing.Point(92, 198);
            this.btn_Withdraw_TampilanDeposit.Name = "btn_Withdraw_TampilanDeposit";
            this.btn_Withdraw_TampilanDeposit.Size = new System.Drawing.Size(108, 41);
            this.btn_Withdraw_TampilanDeposit.TabIndex = 9;
            this.btn_Withdraw_TampilanDeposit.Text = "Withdraw";
            this.btn_Withdraw_TampilanDeposit.UseVisualStyleBackColor = true;
            this.btn_Withdraw_TampilanDeposit.Click += new System.EventHandler(this.btn_Withdraw_TampilanDeposit_Click);
            // 
            // btn_Deposit
            // 
            this.btn_Deposit.Location = new System.Drawing.Point(92, 151);
            this.btn_Deposit.Name = "btn_Deposit";
            this.btn_Deposit.Size = new System.Drawing.Size(108, 41);
            this.btn_Deposit.TabIndex = 8;
            this.btn_Deposit.Text = "Deposit";
            this.btn_Deposit.UseVisualStyleBackColor = true;
            this.btn_Deposit.Click += new System.EventHandler(this.btn_Deposit_Click);
            // 
            // lb_0_TampilanDeposit
            // 
            this.lb_0_TampilanDeposit.AutoSize = true;
            this.lb_0_TampilanDeposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_0_TampilanDeposit.Location = new System.Drawing.Point(112, 113);
            this.lb_0_TampilanDeposit.Name = "lb_0_TampilanDeposit";
            this.lb_0_TampilanDeposit.Size = new System.Drawing.Size(25, 26);
            this.lb_0_TampilanDeposit.TabIndex = 7;
            this.lb_0_TampilanDeposit.Text = "0";
            // 
            // b_Balance_TampilanDeposit
            // 
            this.b_Balance_TampilanDeposit.AutoSize = true;
            this.b_Balance_TampilanDeposit.Location = new System.Drawing.Point(24, 119);
            this.b_Balance_TampilanDeposit.Name = "b_Balance_TampilanDeposit";
            this.b_Balance_TampilanDeposit.Size = new System.Drawing.Size(67, 20);
            this.b_Balance_TampilanDeposit.TabIndex = 6;
            this.b_Balance_TampilanDeposit.Text = "Balance";
            // 
            // btn_LogOut_Depsoit
            // 
            this.btn_LogOut_Depsoit.Location = new System.Drawing.Point(172, 54);
            this.btn_LogOut_Depsoit.Name = "btn_LogOut_Depsoit";
            this.btn_LogOut_Depsoit.Size = new System.Drawing.Size(108, 41);
            this.btn_LogOut_Depsoit.TabIndex = 5;
            this.btn_LogOut_Depsoit.Text = "Log Out";
            this.btn_LogOut_Depsoit.UseVisualStyleBackColor = true;
            this.btn_LogOut_Depsoit.Click += new System.EventHandler(this.btn_LogOut_Depsoit_Click);
            // 
            // lb_UCBank_Deposit
            // 
            this.lb_UCBank_Deposit.AutoSize = true;
            this.lb_UCBank_Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank_Deposit.Location = new System.Drawing.Point(21, 6);
            this.lb_UCBank_Deposit.Name = "lb_UCBank_Deposit";
            this.lb_UCBank_Deposit.Size = new System.Drawing.Size(168, 40);
            this.lb_UCBank_Deposit.TabIndex = 1;
            this.lb_UCBank_Deposit.Text = "UC Bank";
            // 
            // panel_WithdrawView
            // 
            this.panel_WithdrawView.Controls.Add(this.btn_LogOut_WithdrawView);
            this.panel_WithdrawView.Controls.Add(this.lb_0_TampilanWithdrawView);
            this.panel_WithdrawView.Controls.Add(this.lb_InputWithdrawalAmount);
            this.panel_WithdrawView.Controls.Add(this.label1);
            this.panel_WithdrawView.Controls.Add(this.btn_Withdraw_WithdrawView);
            this.panel_WithdrawView.Controls.Add(this.textBox_JumlahWithdrawal);
            this.panel_WithdrawView.Controls.Add(this.lb_UCBank_WithdrawView);
            this.panel_WithdrawView.Location = new System.Drawing.Point(73, 12);
            this.panel_WithdrawView.Name = "panel_WithdrawView";
            this.panel_WithdrawView.Size = new System.Drawing.Size(372, 265);
            this.panel_WithdrawView.TabIndex = 13;
            // 
            // btn_LogOut_WithdrawView
            // 
            this.btn_LogOut_WithdrawView.Location = new System.Drawing.Point(214, 36);
            this.btn_LogOut_WithdrawView.Name = "btn_LogOut_WithdrawView";
            this.btn_LogOut_WithdrawView.Size = new System.Drawing.Size(108, 41);
            this.btn_LogOut_WithdrawView.TabIndex = 14;
            this.btn_LogOut_WithdrawView.Text = "Log Out";
            this.btn_LogOut_WithdrawView.UseVisualStyleBackColor = true;
            this.btn_LogOut_WithdrawView.Click += new System.EventHandler(this.btn_LogOut_WithdrawView_Click);
            // 
            // lb_0_TampilanWithdrawView
            // 
            this.lb_0_TampilanWithdrawView.AutoSize = true;
            this.lb_0_TampilanWithdrawView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_0_TampilanWithdrawView.Location = new System.Drawing.Point(175, 79);
            this.lb_0_TampilanWithdrawView.Name = "lb_0_TampilanWithdrawView";
            this.lb_0_TampilanWithdrawView.Size = new System.Drawing.Size(25, 26);
            this.lb_0_TampilanWithdrawView.TabIndex = 14;
            this.lb_0_TampilanWithdrawView.Text = "0";
            // 
            // lb_InputWithdrawalAmount
            // 
            this.lb_InputWithdrawalAmount.AutoSize = true;
            this.lb_InputWithdrawalAmount.Location = new System.Drawing.Point(69, 117);
            this.lb_InputWithdrawalAmount.Name = "lb_InputWithdrawalAmount";
            this.lb_InputWithdrawalAmount.Size = new System.Drawing.Size(188, 20);
            this.lb_InputWithdrawalAmount.TabIndex = 3;
            this.lb_InputWithdrawalAmount.Text = "Input Withdrawal Amount";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(102, 85);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 20);
            this.label1.TabIndex = 14;
            this.label1.Text = "Balance";
            // 
            // btn_Withdraw_WithdrawView
            // 
            this.btn_Withdraw_WithdrawView.Location = new System.Drawing.Point(104, 179);
            this.btn_Withdraw_WithdrawView.Name = "btn_Withdraw_WithdrawView";
            this.btn_Withdraw_WithdrawView.Size = new System.Drawing.Size(96, 36);
            this.btn_Withdraw_WithdrawView.TabIndex = 5;
            this.btn_Withdraw_WithdrawView.Text = "Withdraw";
            this.btn_Withdraw_WithdrawView.UseVisualStyleBackColor = true;
            this.btn_Withdraw_WithdrawView.Click += new System.EventHandler(this.btn_Withdraw_WithdrawView_Click);
            // 
            // textBox_JumlahWithdrawal
            // 
            this.textBox_JumlahWithdrawal.Location = new System.Drawing.Point(73, 147);
            this.textBox_JumlahWithdrawal.Name = "textBox_JumlahWithdrawal";
            this.textBox_JumlahWithdrawal.Size = new System.Drawing.Size(165, 26);
            this.textBox_JumlahWithdrawal.TabIndex = 4;
            // 
            // lb_UCBank_WithdrawView
            // 
            this.lb_UCBank_WithdrawView.AutoSize = true;
            this.lb_UCBank_WithdrawView.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank_WithdrawView.Location = new System.Drawing.Point(21, 13);
            this.lb_UCBank_WithdrawView.Name = "lb_UCBank_WithdrawView";
            this.lb_UCBank_WithdrawView.Size = new System.Drawing.Size(168, 40);
            this.lb_UCBank_WithdrawView.TabIndex = 2;
            this.lb_UCBank_WithdrawView.Text = "UC Bank";
            // 
            // panel_DepositView
            // 
            this.panel_DepositView.Controls.Add(this.lb_DepositView);
            this.panel_DepositView.Controls.Add(this.textBox_JumlahDeposit);
            this.panel_DepositView.Controls.Add(this.btn_Deposit_DepositView);
            this.panel_DepositView.Controls.Add(this.lb_0_DepositView);
            this.panel_DepositView.Controls.Add(this.lb_Balance_DepositView);
            this.panel_DepositView.Controls.Add(this.btn_LogOut_DepositView);
            this.panel_DepositView.Controls.Add(this.lb_UCBank_DepositView);
            this.panel_DepositView.Location = new System.Drawing.Point(60, 12);
            this.panel_DepositView.Name = "panel_DepositView";
            this.panel_DepositView.Size = new System.Drawing.Size(433, 412);
            this.panel_DepositView.TabIndex = 13;
            // 
            // lb_DepositView
            // 
            this.lb_DepositView.AutoSize = true;
            this.lb_DepositView.Location = new System.Drawing.Point(55, 143);
            this.lb_DepositView.Name = "lb_DepositView";
            this.lb_DepositView.Size = new System.Drawing.Size(169, 20);
            this.lb_DepositView.TabIndex = 6;
            this.lb_DepositView.Text = "Input Deposit Amount:";
            // 
            // textBox_JumlahDeposit
            // 
            this.textBox_JumlahDeposit.Location = new System.Drawing.Point(59, 166);
            this.textBox_JumlahDeposit.Name = "textBox_JumlahDeposit";
            this.textBox_JumlahDeposit.Size = new System.Drawing.Size(165, 26);
            this.textBox_JumlahDeposit.TabIndex = 6;
            // 
            // btn_Deposit_DepositView
            // 
            this.btn_Deposit_DepositView.Location = new System.Drawing.Point(92, 196);
            this.btn_Deposit_DepositView.Name = "btn_Deposit_DepositView";
            this.btn_Deposit_DepositView.Size = new System.Drawing.Size(108, 41);
            this.btn_Deposit_DepositView.TabIndex = 9;
            this.btn_Deposit_DepositView.Text = "Deposit";
            this.btn_Deposit_DepositView.UseVisualStyleBackColor = true;
            this.btn_Deposit_DepositView.Click += new System.EventHandler(this.btn_DepositView_Click);
            // 
            // lb_0_DepositView
            // 
            this.lb_0_DepositView.AutoSize = true;
            this.lb_0_DepositView.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_0_DepositView.Location = new System.Drawing.Point(112, 113);
            this.lb_0_DepositView.Name = "lb_0_DepositView";
            this.lb_0_DepositView.Size = new System.Drawing.Size(25, 26);
            this.lb_0_DepositView.TabIndex = 7;
            this.lb_0_DepositView.Text = "0";
            // 
            // lb_Balance_DepositView
            // 
            this.lb_Balance_DepositView.AutoSize = true;
            this.lb_Balance_DepositView.Location = new System.Drawing.Point(24, 119);
            this.lb_Balance_DepositView.Name = "lb_Balance_DepositView";
            this.lb_Balance_DepositView.Size = new System.Drawing.Size(67, 20);
            this.lb_Balance_DepositView.TabIndex = 6;
            this.lb_Balance_DepositView.Text = "Balance";
            // 
            // btn_LogOut_DepositView
            // 
            this.btn_LogOut_DepositView.Location = new System.Drawing.Point(172, 54);
            this.btn_LogOut_DepositView.Name = "btn_LogOut_DepositView";
            this.btn_LogOut_DepositView.Size = new System.Drawing.Size(108, 41);
            this.btn_LogOut_DepositView.TabIndex = 5;
            this.btn_LogOut_DepositView.Text = "Log Out";
            this.btn_LogOut_DepositView.UseVisualStyleBackColor = true;
            this.btn_LogOut_DepositView.Click += new System.EventHandler(this.btn_LogOut_DepositView_Click);
            // 
            // lb_UCBank_DepositView
            // 
            this.lb_UCBank_DepositView.AutoSize = true;
            this.lb_UCBank_DepositView.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_UCBank_DepositView.Location = new System.Drawing.Point(21, 6);
            this.lb_UCBank_DepositView.Name = "lb_UCBank_DepositView";
            this.lb_UCBank_DepositView.Size = new System.Drawing.Size(168, 40);
            this.lb_UCBank_DepositView.TabIndex = 1;
            this.lb_UCBank_DepositView.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(535, 338);
            this.Controls.Add(this.panel_TampilanLogin);
            this.Controls.Add(this.panel_TampilanDeposit);
            this.Controls.Add(this.panel_TampilanRegister);
            this.Controls.Add(this.panel_WithdrawView);
            this.Controls.Add(this.panel_DepositView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel_TampilanLogin.ResumeLayout(false);
            this.panel_TampilanLogin.PerformLayout();
            this.panel_TampilanRegister.ResumeLayout(false);
            this.panel_TampilanRegister.PerformLayout();
            this.panel_TampilanDeposit.ResumeLayout(false);
            this.panel_TampilanDeposit.PerformLayout();
            this.panel_WithdrawView.ResumeLayout(false);
            this.panel_WithdrawView.PerformLayout();
            this.panel_DepositView.ResumeLayout(false);
            this.panel_DepositView.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_UC_Bank;
        private System.Windows.Forms.Label lb_Username_TampilanLogin;
        private System.Windows.Forms.Label lb_Password_TampilanLogin;
        private System.Windows.Forms.TextBox textBox_Username_TampilanLogin;
        private System.Windows.Forms.TextBox textBox_Password_TampilanLogin;
        private System.Windows.Forms.Button btn_Register_TampilanLogin;
        private System.Windows.Forms.Button btn_Login_TampilanLogin;
        private System.Windows.Forms.Panel panel_TampilanLogin;
        private System.Windows.Forms.Panel panel_TampilanRegister;
        private System.Windows.Forms.TextBox textBox_Password_TampilanRegister;
        private System.Windows.Forms.Label lb_UCBank_TampilanRegister;
        private System.Windows.Forms.TextBox textBox_Username_TampilanRegister;
        private System.Windows.Forms.Label lb_Password_TampilanRegister;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Label lb_Username_TampilanRegister;
        private System.Windows.Forms.Panel panel_TampilanDeposit;
        private System.Windows.Forms.Button btn_LogOut_Depsoit;
        private System.Windows.Forms.Label lb_UCBank_Deposit;
        private System.Windows.Forms.Panel panel_WithdrawView;
        private System.Windows.Forms.Button btn_Withdraw_TampilanDeposit;
        private System.Windows.Forms.Button btn_Deposit;
        private System.Windows.Forms.Label lb_0_TampilanDeposit;
        private System.Windows.Forms.Label b_Balance_TampilanDeposit;
        private System.Windows.Forms.Button btn_Withdraw_WithdrawView;
        private System.Windows.Forms.TextBox textBox_JumlahWithdrawal;
        private System.Windows.Forms.Label lb_InputWithdrawalAmount;
        private System.Windows.Forms.Label lb_UCBank_WithdrawView;
        private System.Windows.Forms.Panel panel_DepositView;
        private System.Windows.Forms.TextBox textBox_JumlahDeposit;
        private System.Windows.Forms.Button btn_Deposit_DepositView;
        private System.Windows.Forms.Label lb_0_DepositView;
        private System.Windows.Forms.Label lb_Balance_DepositView;
        private System.Windows.Forms.Button btn_LogOut_DepositView;
        private System.Windows.Forms.Label lb_UCBank_DepositView;
        private System.Windows.Forms.Label lb_DepositView;
        private System.Windows.Forms.Label lb_0_TampilanWithdrawView;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_LogOut_WithdrawView;
    }
}

